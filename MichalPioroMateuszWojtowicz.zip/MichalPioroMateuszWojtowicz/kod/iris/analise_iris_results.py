from plot_utils import generate_full_report

generate_full_report("trees_number", 1, y_range=(0.8, 1.0))
generate_full_report("epsilon", 1, y_range=(0.85, 1.0))
generate_full_report("max_features", 1, y_range=(0.85, 1.0))
generate_full_report("tree_percentage", 1, y_range=(0.85, 1.0))
